@extends('role.purchasing.layouts.main')
@section('main-container')
    <!-- partial -->

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,1,0" />
    <div class="main-panel">
        <div class="    content-wrapper" style="background-color: #f6f6fb">
            <div class="page-header">
                <h3 class="page-title">
                    <span class="page-title-icon bg-gradient-info text-white me-2">
                        <i class="mdi mdi-home"></i>
                    </span> Dashboard
                </h3>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">
                            <span></span>Overview <i
                                class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="row ">
                <div class="col-12 stretch-card grid-margin">
                    <div class="card border rounded">
                        <div class="card-body shadow  border rounded">
                            <h4 class="card-title mb-3">Form Material Request</h4>
                            <form class="form-sample" method="POST" action="{{ route('inventory.store') }}"
                                id="pricelistForm">
                                @csrf
                                <div class="row stretch-card grid-margin shadow" style="background-color: #f1f1f6">
                                    <div class="col-md mt-3 ">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold">Dept</label>
                                            <input type="text" class="form-control form-control-sm " name="dept"
                                                value=' {{ Auth::user()->departement }}' readonly>
                                        </div>
                                    </div>
                                    <div class="col-md mt-3">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold">Type</label>
                                            <input type="text" class="form-control form-control-sm" name="type"
                                                list="type" required>
                                            <datalist id="type">
                                                <option value="Alat Tulis"></option>
                                                <option value="P3K"></option>
                                                <option value="Spareparts"></option>
                                                <option value="Reguler"></option>

                                            </datalist>
                                        </div>
                                    </div>
                                    <div class="col-md mt-3">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold ">NO PO <sup
                                                    class='text-danger'> Jika ada</sup></label>
                                            <input type="text" class="form-control form-control-sm " name="po"
                                                placeholder="Example : 23xxxxxx" required>
                                        </div>
                                    </div>
                                    <div class="col-md mt-3">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold">Vendor </label>
                                            <input type="text" class="form-control form-control-sm " name="vendor">
                                        </div>
                                    </div>
                                    <div class="col-md mt-3">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold">Lokasi</label>
                                            <input type="text" class="form-control form-control-sm " name="lokasi">
                                        </div>
                                    </div>
                                    <div class="col-md mt-3">
                                        <div class="mb-3" style="font-size: 14px">
                                            <label for="" class="form-label fw-bold">Created</label>
                                            <input type="text" class="form-control form-control-sm " name="created"
                                                value=' {{ Auth::user()->name }}' readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="row  shadow" style="background-color: #f1f1f6">
                                    <div>
                                        <div id="row" class="col mt-3">
                                            <div class="mb-3" style="font-size: 14px">
                                                <label for="" class="form-label fw-bold">Item</label>
                                                <input type="text" id="searchitem" placeholder="Item" list="items"
                                                    name="item" required class="form-control form-control-sm" required>
                                                <datalist id="items">
                                                    @foreach ($items as $data)
                                                        <option>{{ $data->item }}</option>
                                                    @endforeach
                                                </datalist>
                                                <div class="pt-2" id="search-resultsitem"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn-rounded btn btn-gradient-info float-end mt-2">
                                        Submit
                                    </button>
                                </div>
                                <!-- Add this modal at the bottom of your Blade file -->
                                <div class="modal fade" id="successModal" tabindex="-1" role="dialog"
                                    aria-labelledby="successModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="successModalLabel">Success!</h5>

                                            </div>
                                            <div class="modal-body">
                                                Material Request berhasil di tambahkan.
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
                                <!-- Script untuk menangani pencarian item -->
                                <script>
                                    function handleSearchItem() {
                                        var query = $(this).val();
                                        if (query !== '') {
                                            $.ajax({
                                                url: '/searchitemresultinven',
                                                method: 'GET',
                                                data: {
                                                    query: query
                                                },
                                                success: function(data) {
                                                    $(this).nextAll(".pt-2").first().html(data);
                                                }.bind(
                                                    this) // Perhatikan bind(this) untuk mempertahankan konteks elemen yang memicu pencarian
                                            });
                                        } else {
                                            $(this).nextAll(".pt-2").first().html('');
                                        }
                                    }

                                    // Mendaftarkan fungsi handleSearchItem untuk elemen dengan ID "searchitem"
                                    $(document).ready(function() {
                                        $('#searchitem').on('keyup', handleSearchItem);
                                    });
                                </script>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="card rounded-xl shadow">
                    <div class="card-body shadow border">
                        <h3 class="text-center pb-3">Material Request</h3>




                        <form action="" method="GET" novalidate="novalidate">
                            <div class="d-flex pb-2">
                                <input type="text" name="search" type="search"
                                    class="form-control form-control-sm">
                                <button type="submit" class="btn btn-sm btn-gradient-success ">Search</button>
                            </div>

                        </form>

                        <div class="table-responsive">
                            <style>
                                th.sticky {
                                    position: sticky;
                                    left: 0;
                                    background-color: #f1f1f6;
                                }
                            </style>
                            <table class="table" id="materialRequestTable">
                                <thead>
                                    <tr class="" style="background-color: #f1f1f6">

                                        <th style="font-size: 14px; width: 40px" class="py-2 my-2 sticky"> ID </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> TYPE </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> ITEM </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> LOCATION </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> QTY </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> DEPT </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> DATE CREATED </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> RECORD </th>

                                    </tr>
                                </thead>
                                <tbody id="pricelistTableBody">
                                    @foreach ($items as $data)
                                        <tr>
                                            <div class="table-responsive">
                                                <style>
                                                    td.sticky {
                                                        position: sticky;
                                                        left: 0;
                                                        background-color: #ffffff;
                                                    }

                                                    .ellipsis {
                                                        white-space: nowrap;
                                                        overflow: hidden;
                                                        text-overflow: ellipsis;
                                                        max-width: 30ch;
                                                        /* Atau sesuaikan dengan ukuran yang Anda inginkan */
                                                    }
                                                </style>



                                                <td style="padding-top: 3px; padding-bottom:3px;" class="sticky">
                                                    {{ $data->id }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ $data->type }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ $data->item }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ $data->lokasi }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ $data->qty }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ $data->dept }}</td>
                                                <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    {{ \Carbon\Carbon::parse($data->created_at)->format('j M y') }}</td>
                                                 <td style="padding-top: 3px; padding-bottom:3px;" class="">
                                                    <a class="btn btn-sm btn-gradient-success" href="{{ route('inventory.show', $data->id) }}">Detail</a>
                                                </td>
                                            </div>
                                        </tr>
                                    @endforeach
                                </tbody>


                            </table>
                            {{-- <div class="pt-2">
                                {{ $materialrequests->links() }}
                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    @endsection
