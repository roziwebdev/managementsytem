@extends('role.purchasing.layouts.main')
@section('main-container')
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,1,0" />
    <div class="main-panel">
        <div class="    content-wrapper" style="background-color: #f6f6fb">



            <div class="">
                <div class="card rounded-xl shadow">
                    <div class="card-body shadow border">
                        <h3 class="text-center pb-3">Items In</h3>
                        <div class="table-responsive">
                            <style>
                                th.sticky {
                                    position: sticky;
                                    left: 0;
                                    background-color: #f1f1f6;
                                }
                            </style>
                            <table class="table" id="materialRequestTable">
                                <thead>
                                    <tr class="" style="background-color: #f1f1f6">
                                        <th style="font-size: 14px" class="py-2 my-2"> ITEM </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> SPECS </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> SIZE </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> QTY IN</th>
                                        <th style="font-size: 14px" class="py-2 my-2"> LOCATION </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> DATE CREATED </th>
                                    </tr>
                                </thead>
                                <tbody id="pricelistTableBody">
                                    @foreach ($inventorylist as $data)
                                        <tr>
                                            <div class="table-responsive">
                                                <style>
                                                    td.sticky {
                                                        position: sticky;
                                                        left: 0;
                                                        background-color: #ffffff;
                                                    }

                                                    .ellipsis {
                                                        white-space: nowrap;
                                                        overflow: hidden;
                                                        text-overflow: ellipsis;
                                                        max-width: 30ch;
                                                        /* Atau sesuaikan dengan ukuran yang Anda inginkan */
                                                    }
                                                </style>



                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->item }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->specs }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->size }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->qty }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->lokasi }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ \Carbon\Carbon::parse($data->created_at)->format('j M y') }}</td>



                                            </div>


                                        </tr>
                                    @endforeach
                                </tbody>


                            </table>
                            {{-- <div class="pt-2">
                                {{ $materialrequests->links() }}
                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>
            <div class="pt-5">
                <div class="card rounded-xl shadow">
                    <div class="card-body shadow border">
                        <h3 class="text-center pb-3">Items Out</h3>
                        <div class="table-responsive">
                            <style>
                                th.sticky {
                                    position: sticky;
                                    left: 0;
                                    background-color: #f1f1f6;
                                }
                            </style>
                            <table class="table" id="materialRequestTable">
                                <thead>
                                    <tr class="" style="background-color: #f1f1f6">
                                        <th style="font-size: 14px" class="py-2 my-2"> ITEM </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> SPECS </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> SIZE </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> QTY OUT </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> LOCATION </th>
                                        <th style="font-size: 14px" class="py-2 my-2"> DATE CREATED </th>

                                    </tr>
                                </thead>
                                <tbody id="pricelistTableBody">
                                    @foreach ($inventorywd as $data)
                                        <tr>
                                            <div class="table-responsive">
                                                <style>
                                                    td.sticky {
                                                        position: sticky;
                                                        left: 0;
                                                        background-color: #ffffff;
                                                    }

                                                    .ellipsis {
                                                        white-space: nowrap;
                                                        overflow: hidden;
                                                        text-overflow: ellipsis;
                                                        max-width: 30ch;
                                                        /* Atau sesuaikan dengan ukuran yang Anda inginkan */
                                                    }
                                                </style>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->item }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->specs }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->size }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ $data->qty }}</td>
                                                <td style="padding-top: 4px; padding-bottom:3px;" class="">
                                                    {{ $data->lokasi }}</td>
                                                <td style="padding-top: 4px; padding-bottom:4px;" class="">
                                                    {{ \Carbon\Carbon::parse($data->created_at)->format('j M y') }}</td>



                                            </div>


                                        </tr>
                                    @endforeach
                                </tbody>


                            </table>
                            {{-- <div class="pt-2">
                                {{ $materialrequests->links() }}
                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    @endsection

    {{-- <h1>Detail Produk: {{ $item->item }}</h1>



    <h2>Barang Masuk</h2>
    @foreach ($inventorylist as $item)
        <p>{{ $item->item }} - QTY: {{ $item->qty }}</p>
    @endforeach

    <h2>Barang Keluar</h2>
    @foreach ($inventorywd as $item)
        <p>{{ $item->item }} - QTY: {{ $item->qty }}</p>
    @endforeach --}}
