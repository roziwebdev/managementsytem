@include('role.purchasing.layouts.header')
@yield('main-container')
@include('role.purchasing.layouts.footer')
