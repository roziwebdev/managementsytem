@extends('role.purchasing.layoutsmrmanager.main')
@section('main-container')
    <style>
        table td,
        table th {
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }

        thead th {
            color: #fff;
        }

        .card {
            border-radius: .5rem;
        }

        .table-scroll {
            border-radius: .5rem;
        }

        .table-scroll table thead th {
            font-size: 1rem;
        }

        thead {
            top: 0;
            position: sticky;
        }

        .search-sec {
            padding: 2rem;
        }

        .search-slt {
            display: block;
            width: 100%;
            font-size: 0.875rem;
            line-height: 1.5;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .wrn-btn {
            width: 100%;
            font-size: 16px;
            font-weight: 400;
            text-transform: capitalize;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .search-sec {
            padding: 2rem;
        }

        .search-slt {
            display: block;
            width: 100%;
            font-size: 0.875rem;
            line-height: 1.5;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .wrn-btn {
            width: 100%;
            font-size: 16px;
            font-weight: 400;
            text-transform: capitalize;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .bold-td {
            font-weight: bold;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <div>
        <main class="content">
            <div class="container-fluid p-0">
                <div class="row">
                    <div class="col-12">
                        <h1 class="h2 mb-3"><strong>List</strong> Material Request</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 offset-lg-3 mb-5">
                        <form action="" method="GET" novalidate="novalidate">
                            <div class="row">
                                <div class="col-lg-6">
                                    <input name="search" type="search" class="form-control search-slt"
                                        placeholder="Enter Search">
                                </div>
                                <div class="col-lg-3">
                                    <select class="form-control search-slt">
                                        <option value="created" {{ request('sort') == 'created' ? 'selected' : '' }}>Created
                                        </option>
                                        <option value="ascending" {{ request('sort') == 'ascending' ? 'selected' : '' }}>
                                            Ascending</option>
                                    </select>
                                </div>
                                <div class="col-lg-3">
                                    <button type="submit" class="btn btn-primary wrn-btn">Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Other content goes here -->
            </div>


            <section class="intro">
                <div class="bg-image h-100" style="background-color: #f5f7fa;">
                    <div class="mask d-flex align-items-center h-100">
                        <div class="container">
                            <div class="row justify-content-center">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body p-0">
                                            <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true"
                                                style="position: relative; height: 600px">

                                                <table class="table table-striped mb-0">
                                                    <thead style="background-color: #1a202c" class="text-light">
                                                        <tr>
                                                            <th class="text-dark" scope="col">No</th>
                                                            <th class="text-dark" scope="col">
                                                                MR Date
                                                            </th>
                                                            <th class="text-dark" scope="col">
                                                                <div class="dropdown">
                                                                    <div class="dropdown-toggle" type="button"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        MR Number
                                                                    </div>
                                                                    <ul class="dropdown-menu position-relative">
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="mrnumber-asc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Ascending</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="mrnumber-desc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Descending</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </th>
                                                            <th class="text-dark" scope="col">Dept</th>
                                                            <th class="text-dark" scope="col">Type</th>
                                                            <th class="text-dark" scope="col">
                                                                <div class="dropdown">
                                                                    <div class="dropdown-toggle" type="button"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        JOB/Product
                                                                    </div>
                                                                    <ul class="dropdown-menu position-relative">
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="job-asc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Ascending</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="job-desc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Descending</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </th>
                                                            <th class="text-dark" scope="col">Eta User</th>
                                                            <th class="text-dark" scope="col">
                                                                <div class="dropdown">
                                                                    <div class="dropdown-toggle" type="button"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        Item
                                                                    </div>
                                                                    <ul class="dropdown-menu position-relative">
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="item-asc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Ascending</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="item-desc">
                                                                                <button type="submit"
                                                                                    class="btn btn-link">Descending</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </th>
                                                            <th class="text-dark" scope="col">Qty</th>
                                                            <th class="text-dark" scope="col">Status</th>
                                                            <th class="text-dark" scope="col">Manage</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($materialrequests as $user)
                                                            <tr @if ($user->status === 'Waiting') class="bold-td" @endif>
                                                                @php
                                                                    $etauserArray = json_decode($user->etauser, true);
                                                                    $itemArray = json_decode($user->item, true);
                                                                    $sizeArray = json_decode($user->size, true);
                                                                    $specsArray = json_decode($user->specs, true);
                                                                    $qtyArray = json_decode($user->qty, true);

                                                                    // Mengambil item pertama dari masing-masing kolom
                                                                    $firstEtauser = reset($etauserArray);
                                                                    $firstItem = reset($itemArray);
                                                                    $firstSize = reset($sizeArray);
                                                                    $firstSpecs = reset($specsArray);
                                                                    $firstQty = reset($qtyArray);
                                                                @endphp
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $loop->iteration }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $user->created_at->format('d-m-y') }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $user->id }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $user->dept }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $user->type }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $user->job }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $firstEtauser }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $firstItem }}
                                                                </td>
                                                                <td data-materialrequest-id="{{ $user->id }}"
                                                                    @if ($user->status != 'Waiting') class="not-bold-td" @endif>
                                                                    {{ $firstQty }}
                                                                </td>
                                                                <td>
                                                                    <button
                                                                        class="btn btn-action badge @if ($user->status == 'Waiting') bg-warning @elseif($user->status == 'Approve') bg-success @elseif($user->status == 'Declined') bg-danger @endif"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#editStatusModal{{ $user->id }}">
                                                                        {{ $user->status }}
                                                                    </button>
                                                                </td>
                                                                <td class="d-flex">
                                                                    <div>
                                                                        @if ($user->hasChat())
                                                                            {{-- Periksa apakah ada data chat terkait MaterialRequest --}}
                                                                            <button
                                                                                class="btn btn-action btn-primary btn-tambah-chat"
                                                                                data-materialrequest-id="{{ $user->id }}">
                                                                                <i class="align-middle"
                                                                                    data-feather="message-square"></i>
                                                                            </button>
                                                                        @else
                                                                            <button
                                                                                class="btn btn-action btn-success btn-tambah-chat"
                                                                                data-materialrequest-id="{{ $user->id }}">
                                                                                <i class="align-middle"
                                                                                    data-feather="message-square"></i>

                                                                            </button>
                                                                        @endif
                                                                    </div>
                                                                    <div class="px-3">
                                                                        <a href="{{ route('mr.show', $user->id) }}"
                                                                            class="btn btn-action btn-dark">
                                                                            <i class=" btn-action align-middle"
                                                                                data-feather="list"></i>

                                                                        </a>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                        <script>
                                                            < script >
                                                                document.addEventListener("DOMContentLoaded", function() {
                                                                    const chatButtons = document.querySelectorAll(".btn-tambah-chat");
                                                                    const detailButtons = document.querySelectorAll(".btn-dark");
                                                                    const statusButtons = document.querySelectorAll(".badge");

                                                                    function removeBoldClass(event) {
                                                                        const materialRequestId = event.target.getAttribute("data-materialrequest-id");

                                                                        document.querySelectorAll(`td[data-materialrequest-id="${materialRequestId}"]`).forEach(function(
                                                                            td) {
                                                                            td.classList.remove("bold-td");
                                                                        });

                                                                        // Simpan status klik di localStorage
                                                                        localStorage.setItem(`bold-td-clicked-${materialRequestId}`, "true");
                                                                    }

                                                                    chatButtons.forEach(function(button) {
                                                                        button.addEventListener("click", removeBoldClass);
                                                                    });

                                                                    detailButtons.forEach(function(button) {
                                                                        button.addEventListener("click", removeBoldClass);
                                                                    });

                                                                    statusButtons.forEach(function(button) {
                                                                        button.addEventListener("click", function(event) {
                                                                            const materialRequestId = event.target.getAttribute("data-materialrequest-id");
                                                                            const userStatus = event.target.textContent.trim();

                                                                            if (userStatus !== "Waiting") {
                                                                                document.querySelectorAll(
                                                                                    `td[data-materialrequest-id="${materialRequestId}"]`).forEach(
                                                                                    function(td) {
                                                                                        td.classList.remove("bold-td");
                                                                                    });
                                                                            }

                                                                            // Simpan status klik di localStorage
                                                                            localStorage.setItem(`bold-td-clicked-${materialRequestId}`, "true");
                                                                        });
                                                                    });

                                                                    // Cek jika status sudah diubah sebelumnya
                                                                    chatButtons.forEach(function(button) {
                                                                        const materialRequestId = button.getAttribute("data-materialrequest-id");
                                                                        if (localStorage.getItem(`bold-td-clicked-${materialRequestId}`) === "true") {
                                                                            document.querySelectorAll(`td[data-materialrequest-id="${materialRequestId}"]`).forEach(
                                                                                function(td) {
                                                                                    td.classList.remove("bold-td");
                                                                                });
                                                                        }
                                                                    });
                                                                }); <
                                                            />
                                                        </script>


                                            </div>

                                            </tbody>
                                            </table>
                                            <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                                                integrity="sha384-KyZXEAg3QhqLMpG8r+3gR6z5nxR8w0H8b3MRtLQ5l/EJw5xWxB25DCV3EAyj4xqs1" crossorigin="anonymous">
                                            </script>
                                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
                                                integrity="sha384-o3z24p0zGLi0fAEfjrN6b4CK6d5Cn+8SlBQ+Iu5l5n0v1L5VvybRT6rF5F+YaaEK5" crossorigin="anonymous">
                                            </script>



                                            <!--Modal!-->

                                            @foreach ($materialrequests as $user)
                                                <!-- Modal untuk mengedit status -->
                                                <div class="modal fade" id="editStatusModal{{ $user->id }}"
                                                    tabindex="-1" role="dialog"
                                                    aria-labelledby="editStatusModalLabel{{ $user->id }}"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="editStatusModalLabel{{ $user->id }}">Approval
                                                                </h5>
                                                            </div>
                                                            <div class="modal-body">
                                                                <!-- Form untuk mengedit status -->
                                                                @if ($user->status == 'Approve')
                                                                    {{-- Cek status sebelumnya --}}
                                                                    <p>Status sudah Approve/Declined sebelumnya.</p>
                                                                @elseif ($user->status == 'Declined')
                                                                    {{-- Cek status sebelumnya --}}
                                                                    <p>Status sudah Approve/Declined sebelumnya.</p>
                                                                @else
                                                                    <form
                                                                        action="{{ route('update_statusmanager', $user->id) }}"
                                                                        method="POST">
                                                                        @csrf
                                                                        @method('PUT')
                                                                        <div class="">
                                                                            {{-- Radio buttons untuk mengubah status --}}
                                                                            <h5>Press to Waiting</h5>
                                                                            <label class="btn btn-warning active">
                                                                                <input type="radio" value="Waiting"
                                                                                    id="newStatus" name="newStatus">
                                                                                Waiting
                                                                            </label>
                                                                            <hr>

                                                                            <h5>Approve MR</h5>
                                                                            <label class="btn btn-success ">
                                                                                <input type="radio" value="Approve"
                                                                                    id="newStatus" name="newStatus">
                                                                                Approve
                                                                            </label>
                                                                            <hr>
                                                                            <h5>Declined MR</h5>
                                                                            <label class="btn btn-danger ">
                                                                                <input type="radio" value="Declined"
                                                                                    id="newStatus" name="newStatus" />
                                                                                Declined
                                                                            </label>
                                                                        </div>
                                                                        <hr>
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Close</button>
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Save
                                                                            changes</button>
                                                                    </form>
                                                                @endif
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script>
                                                    $(document).ready(function() {
                                                        $(".btn-tambah-chat, .btn-dark").click(function() {
                                                            // Saat tombol "Detail" atau "Chat" diklik, hilangkan kelas "bold-td" dari semua td
                                                            $("td").removeClass("bold-td");
                                                        });
                                                    });
                                                </script>
                                            @endforeach



                                            <!-- Offcanvas untuk chat -->
                                            <!-- Sidebar Offcanvas -->
                                            <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebar"
                                                aria-labelledby="sidebarLabel">
                                                <div class="offcanvas-header">
                                                    <h5 class="offcanvas-title" id="sidebarLabel">Comment
                                                    </h5>
                                                    <button type="button" class="btn-close text-reset"
                                                        id="refreshButton" data-bs-dismiss="offcanvas"
                                                        aria-label="Close"></button>
                                                    <script>
                                                        document.getElementById('refreshButton').addEventListener('click', function() {
                                                            location.reload(); // Fungsi ini akan me-refresh halaman
                                                        });
                                                    </script>


                                                </div>
                                                <div class="offcanvas-body">

                                                    <form id="chat-form" enctype="multipart/form-data">
                                                        <!-- Tambahkan enctype="multipart/form-data" untuk mengunggah file -->
                                                        @csrf
                                                        <input type="hidden" id="selected-materialrequest-id"
                                                            name="materialrequest_id" value="">
                                                        <div class="mb-3">
                                                            <label for="chat" class="form-label">Chat</label>
                                                            <input type="text" class="form-control" id="chat"
                                                                placeholder="Write Here..." name="chat" required>
                                                        </div>
                                                        <div class="mb-3">

                                                            <input hidden type="file" class="form-control"
                                                                id="image" name="image">

                                                        </div>
                                                        <button type="submit" class="btn btn-primary">Submit</button>
                                                    </form>

                                                    <br />
                                                    <br />
                                                    <br />
                                                    <div class="d-flex">
                                                        <div id="daftar-chat">

                                                            <!-- Daftar alamat akan diisi oleh JavaScript -->
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>




                                            <!-- Tombol "Autofill" untuk mengisi input type="file" secara otomatis -->


                                            <script>
                                                function autofillFileInput() {
                                                    var imageSrc = $("#preview-image").attr("src"); // Dapatkan URL gambar dari elemen gambar
                                                    var fileInput = document.getElementById("image"); // Dapatkan elemen input type="file"
                                                    var blob = fetch(imageSrc)
                                                        .then(response => response.blob()) // Konversi gambar ke Blob
                                                        .then(blob => {
                                                            var file = new File([blob], "autofilled-image.jpg"); // Buat File dari Blob
                                                            var fileList = new DataTransfer(); // Buat objek DataTransfer
                                                            fileList.items.add(file); // Tambahkan file ke objek DataTransfer
                                                            fileInput.files = fileList.files; // Isi input type="file" dengan objek DataTransfer
                                                        });
                                                }

                                                // Jalankan fungsi autofillFileInput() saat halaman dimuat
                                                $(document).ready(function() {
                                                    autofillFileInput();
                                                });

                                                // Handle submit form input chat
                                                $("#chat-form").submit(function(e) {
                                                    e.preventDefault();

                                                    // Kirim permintaan AJAX untuk menyimpan chat baru
                                                    $.ajax({
                                                        url: "/manager/chat",
                                                        type: "POST",
                                                        data: new FormData(this),
                                                        contentType: false,
                                                        processData: false,
                                                        success: function(data) {
                                                            // Ganti URL gambar dengan URL gambar baru
                                                            $("#preview-image").attr("src", data.newImageURL);

                                                            // Isi ulang input type="file" dengan gambar baru
                                                            autofillFileInput();

                                                            // Kosongkan form input chat
                                                            $("#chat").val('');
                                                        }
                                                    });
                                                });



                                                $(document).ready(function() {
                                                    $(".btn-tambah-chat").click(function() {
                                                        var materialrequestId = $(this).data('materialrequest-id');
                                                        $("#selected-materialrequest-id").val(materialrequestId);

                                                        // Kosongkan daftar chat dalam sidebar
                                                        $("#daftar-chat").empty();
                                                        $("#gambar-chat").empty(); // Kosongkan elemen gambar

                                                        // Kirim permintaan AJAX untuk mendapatkan daftar chat
                                                        $.get("/manager/chat/" + materialrequestId, function(data) {
                                                            $.each(data.chats, function(index, chat) {
                                                                // Membuat satu kolom grid Bootstrap untuk setiap chat
                                                                var chatItem = '<div class="row mb-4">';

                                                                // Elemen gambar (avatar)
                                                                if (chat.image) {
                                                                    chatItem += '<div class="col-auto">';
                                                                    chatItem +=
                                                                        '<img class="avatar rounded-circle me-1" src="/storage/' +
                                                                        chat.image + '" alt="Chat Image">';
                                                                    chatItem += '</div>';
                                                                }

                                                                // Elemen teks chat
                                                                chatItem += '<div class="col">';
                                                                chatItem += '<p>' + chat.chat + '</p>';
                                                                chatItem += '</div>';

                                                                chatItem += '</div>'; // Menutup baris grid

                                                                $("#daftar-chat").append(chatItem);
                                                            });
                                                        });

                                                        // Munculkan sidebar sesuai dengan nama yang diklik
                                                        $("#sidebar").addClass("show");
                                                    });

                                                    // Handle submit form input chat
                                                    $("#chat-form").submit(function(e) {
                                                        e.preventDefault();

                                                        // Menggunakan FormData untuk mengirim data gambar
                                                        var formData = new FormData(this);

                                                        // Kirim permintaan AJAX untuk menyimpan chat baru
                                                        $.ajax({
                                                            url: "/manager/chat",
                                                            type: "POST",
                                                            data: formData,
                                                            contentType: false,
                                                            processData: false,
                                                            success: function(data) {
                                                                // Tambahkan chat baru ke daftar chat dalam sidebar
                                                                var chatItem = '<div class="row mb-4">';

                                                                // Elemen gambar (avatar)
                                                                if (data.image) {
                                                                    chatItem += '<div class="col-auto">';
                                                                    chatItem += '<img class="avatar img-fluid rounded me-1" src="' +
                                                                        data.image +
                                                                        '" alt="Chat Image">';
                                                                    chatItem += '</div>';
                                                                }

                                                                // Elemen teks chat
                                                                chatItem += '<div class="col">';
                                                                chatItem += '<p>' + data.chat + '</p>';
                                                                chatItem += '</div>';

                                                                chatItem += '</div>'; // Menutup baris Bootstrap

                                                                // Tambahkan chat baru ke daftar chat dalam sidebar
                                                                $("#daftar-chat").append(chatItem);

                                                                // Simpan URL gambar di localStorage
                                                                if (data.image) {
                                                                    localStorage.setItem('chat_image', data.image);
                                                                }

                                                                // Kosongkan form input chat dan gambar
                                                                $("#chat").val('');
                                                                $("#image").val('');
                                                            }
                                                        });
                                                    });

                                                    // Cek apakah ada URL gambar yang disimpan di localStorage
                                                    var storedChatImage = localStorage.getItem('chat_image');
                                                    if (storedChatImage) {
                                                        // Tampilkan gambar yang disimpan
                                                        $("#gambar-chat").html("<img class='avatar img-fluid rounded me-1' src='" + storedChatImage +
                                                            "' alt='Chat Image'>");
                                                    }
                                                });
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
    </section>
    </div>
    </main>
    <img hidden id="preview-image" src="{{ URL::asset('frontend/img/photos/gm.jpg') }}" alt="Preview Image" />
    </div>
@endsection
