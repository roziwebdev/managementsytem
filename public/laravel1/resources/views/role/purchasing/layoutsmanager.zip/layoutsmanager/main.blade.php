@include('role.purchasing.layoutsmanager.header')
@yield('main-container')
@include('role.purchasing.layoutsmanager.footer')
