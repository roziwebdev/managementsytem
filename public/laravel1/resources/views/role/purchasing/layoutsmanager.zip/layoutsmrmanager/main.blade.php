@include('role.purchasing.layoutsmrmanager.header')
@yield('main-container')
@include('role.purchasing.layoutsmrmanager.footer')
