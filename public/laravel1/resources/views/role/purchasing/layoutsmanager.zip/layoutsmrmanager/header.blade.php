<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title>ARJAYA TEAM</title>


    <!-- slect2!-->


    <link href="{{ URL::asset('frontend/css/app.css') }}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!--End MDB kit  !-->
</head>

<body>

    <div class="wrapper">


        <div class="main">
            <nav class="navbar navbar-expand navbar-light navbar-bg">
                <button onclick="window.history.back()" class="btn btn-primary">
                    Back
                </button>

                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">

                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                                data-bs-toggle="dropdown">
                                <i class="align-middle" data-feather="settings"></i>
                            </a>

                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
                                data-bs-toggle="dropdown">
                                @if (auth()->user()->profile_photo_path)
                                    <img src="{{ asset('storage/' . auth()->user()->profile_photo_path) }}"
                                        alt="{{ auth()->user()->name }}" class="avatar img-fluid rounded me-1" />
                                    <span class="text-green-900">{{ Auth::user()->name }}
                                        ({{ Auth::user()->roles }})</span>
                                @else
                                    <img src="{{ URL::asset('frontend/img/photos/rozi.png') }}"
                                        alt="{{ auth()->user()->name }}" class="avatar img-fluid rounded me-1" />
                                    <span class="text-green-900">{{ Auth::user()->name }}
                                        ({{ Auth::user()->roles }})</span>
                                @endif
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="pages-profile.html"><i class="align-middle me-1"
                                        data-feather="user"></i> Profile</a>
                                <a class="dropdown-item" href="{{ route('profile.edit') }}"><i class="align-middle me-1"
                                        data-feather="settings"></i> Settings Account</a>



                                <div class="dropdown-divider"></div>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf

                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                        onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                        Log out
                                    </a>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
