@extends('role.purchasing.layoutsmrdept.main')
@section('main-container')
    <style>
        table td,
        table {
            text-overflow: ellipsis;
            white-space: nowrap;
            overflow: hidden;
        }

        thead {
            color: #fff;
        }

        .card {
            border-radius: .5rem;
        }

        .table-scroll {
            border-radius: .5rem;
        }

        .table-scroll table thead th {
            font-size: 0.8rem;
        }

        td {
            font-size: 0.8rem;
        }

        thead {
            top: 0;
            position: sticky;
        }


        .search-sec {
            padding: 2rem;
        }

        .search-slt {
            display: block;
            width: 100%;
            font-size: 0.875rem;
            line-height: 1.5;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .wrn-btn {
            width: 100%;
            font-size: 16px;
            font-weight: 400;
            text-transform: capitalize;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .search-sec {
            padding: 2rem;
        }

        .search-slt {
            display: block;
            width: 100%;
            font-size: 0.875rem;
            line-height: 1.5;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }

        .wrn-btn {
            width: 100%;
            font-size: 16px;
            font-weight: 400;
            text-transform: capitalize;
            height: calc(3rem + 2px) !important;
            border-radius: 0;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <div>
        <main class="content">
            <div class="container-fluid p-0">
                <div class="row">
                    <div class="col-12">
                        <h1 class="h2 mb-3"><strong>Detail </strong> Material Request MR-{{ $materialrequest->id }}</h1>
                    </div>
                </div>

            </div>


            <section class="intro">
                <div class="">
                    <div class="">
                        <div class="">
                            <div class="row justify-content-center">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body p-0">
                                            <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true"
                                                style="position: relative; height: 300px">

                                                <table class="table table-striped mb-0">
                                                    <thead style="background-color: #1a202c" class="text-light">
                                                        <tr>
                                                            <th class="text-light bg-dark" scope="col">No</th>



                                                            <th class="text-light bg-dark" scope="col">Dept</th>
                                                            <th class="text-light bg-dark" scope="col">Type</th>
                                                            <th class="text-light bg-dark" scope="col">
                                                                <div class="dropdown">
                                                                    <div class="dropdown-toggle" type="button"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        JOB/Product
                                                                    </div>
                                                                    <ul class="dropdown-menu position-">
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="job-asc">
                                                                                <button type="submit" class="btn btn-">A -
                                                                                    Z</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="job-desc">
                                                                                <button type="submit" class="btn btn-">Z -
                                                                                    A</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </th>
                                                            <th class="text-light bg-dark" scope="col">Eta User</th>
                                                            <th class="text-light bg-dark" scope="col">
                                                                <div class="dropdown">
                                                                    <div class="dropdown-toggle" type="button"
                                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                                        Item
                                                                    </div>
                                                                    <ul class="dropdown-menu position-">
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="item-asc">
                                                                                <button type="submit"
                                                                                    class="btn btn-">Ascending</button>
                                                                            </form>
                                                                        </li>
                                                                        <li>
                                                                            <form action="" method="GET"
                                                                                novalidate="novalidate">
                                                                                <input type="hidden" name="sort"
                                                                                    value="item-desc">
                                                                                <button type="submit"
                                                                                    class="btn btn-">Descending</button>
                                                                            </form>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </th>
                                                            <th class="text-light bg-dark" scope="col">Specs</th>
                                                            <th class="text-light bg-dark" scope="col">Qty</th>
                                                            <th class="text-light bg-dark" scope="col">Size</th>
                                                            <th class="text-light bg-dark" scope="col">Remarks</th>
                                                            <th class="text-light bg-dark" scope="col">Serat p</th>
                                                            <th class="text-light bg-dark" scope="col">Serat l</th>


                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @php
                                                            $items = json_decode($materialrequest->item);
                                                            $specs = json_decode($materialrequest->specs);
                                                            $etausers = json_decode($materialrequest->etauser);
                                                            $sizes = json_decode($materialrequest->size);
                                                            $qtys = json_decode($materialrequest->qty);
                                                            $remarks = json_decode($materialrequest->mrdate);
                                                            // Gabungkan semua data menjadi satu array dengan zip
                                                            $combinedData = array_map(null, $items, $specs, $etausers, $sizes, $qtys, $remarks);
                                                        @endphp
                                                        @foreach ($combinedData as $data)
                                                            <tr>

                                                                <td>1</td>


                                                                <td>{{ $materialrequest->dept }}</td>
                                                                <td>{{ $materialrequest->type }}</td>
                                                                <td>{{ $materialrequest->job }}</td>
                                                                <td>{{ $data[2] }}</td> {{-- ETA User --}}
                                                                <td>{{ $data[0] }}</td> {{-- Item --}}
                                                                <td>{{ $data[1] }}</td> {{-- Specs --}}
                                                                <td>{{ $data[4] }}</td> {{-- Qty --}}
                                                                <td>{{ $data[3] }}</td> {{-- Size --}}
                                                                <td>{{ $data[5] }}</td> {{-- Remarks --}}
                                                                <td>{{ $materialrequest->arahseratp }}</td>
                                                                <td>{{ $materialrequest->arahseratl }}</td>
                                                            </tr>
                                                        @endforeach


                                            </div>

                                            </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </div>
                                <main class="content">
                                    <div class="container-fluid p-0">
                                        <div class="mb-3">
                                            <h1 class="h3 d-inline align-middle">Forms</h1>
                                            <a class="badge bg-dark text-white ms-2" href="upgrade-to-pro.html">
                                                Purchase Order
                                            </a>
                                        </div>
                                        <form method="POST" action="{{ route('purchaseorder.store') }}">
                                            @csrf
                                            <div class="row">
                                                <div class="col-12 col-lg-6">
                                                    <div class="card">


                                                        <div class="card-header">
                                                            <h5 class="card-title mb-0">MR Number</h5>
                                                        </div>
                                                        <div class="card-body">
                                                            <input type="text" class="form-control"
                                                                placeholder="Product Name" name="mrnumber"
                                                                value="{{ $materialrequest->id }}">
                                                        </div>
                                                        <div class="card-header">
                                                            <h5 class="card-title mb-0">Product Name / JOB</h5>
                                                        </div>
                                                        <div class="card-body">
                                                            <input type="text" class="form-control"
                                                                placeholder="Product Name" name="product"
                                                                value="{{ $materialrequest->job }}">
                                                        </div>

                                                        <div class="card-header">
                                                            <h5 class="card-title mb-0">Supplier</h5>
                                                        </div>
                                                        <div class="card-body">

                                                            <input type="text" id="search" placeholder="Supplier"
                                                                list="supplier" name="supplier" class="form-control">
                                                            <datalist id="supplier">
                                                                @foreach ($supplier as $data)
                                                                    <option>{{ $data->supplier }}</option>
                                                                @endforeach
                                                            </datalist>
                                                            <div class="pt-2" id="search-results"></div>

                                                            <script>
                                                                $(document).ready(function() {
                                                                    $('#search').on('keyup', function() {
                                                                        var query = $(this).val();
                                                                        if (query !== '') {
                                                                            $.ajax({
                                                                                url: '/searchsupplier',
                                                                                method: 'GET',
                                                                                data: {
                                                                                    query: query
                                                                                },
                                                                                success: function(data) {
                                                                                    $('#search-results').html(data);
                                                                                }
                                                                            });
                                                                        } else {
                                                                            $('#search-results').html('');
                                                                        }
                                                                    });
                                                                });
                                                            </script>

                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">MR Date</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <input type="date" readonly name="mrtanggal"
                                                                        class="form-control"
                                                                        value="{{ $materialrequest->created_at->format('Y-m-d') }}" />

                                                                </div>

                                                                <input type="hidden" value="Waiting" name="status"
                                                                    class="form-control" />
                                                            </div>
                                                            <div class="col">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Alamat Kirim
                                                                    </h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <input type="text" name="alamat"
                                                                        class="form-control" list="alamat" />
                                                                    <datalist id="alamat">
                                                                        <option
                                                                            value="JL Imam Bonjol 838 Singosari, Malang">
                                                                        </option>
                                                                        <option value="JL Mondoroko 14 Singosari, Malang">
                                                                        </option>
                                                                    </datalist>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Vat</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <input type="text" name="vat"
                                                                        placeholder="VAT" class="form-control" />

                                                                </div>
                                                            </div>

                                                            <div class="col">
                                                                <div class="card-header">
                                                                    <h5 class="card-title mb-0">Note</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <input type="text" name="ref"
                                                                        placeholder="Ref" class="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-6">


                                                    <div class="card">
                                                        <div id="row">
                                                            <div class="card-header">
                                                                <h5 class="card-title mb-0">Item</h5>
                                                            </div>
                                                            <div class="card-body">
                                                                <input type="text" id="searchitem" placeholder="Item"
                                                                    list="item" name="item[]" class="form-control">
                                                                <datalist id="item">
                                                                    @foreach ($item as $data)
                                                                        <option>{{ $data->item }}</option>
                                                                    @endforeach
                                                                </datalist>
                                                                <div class="pt-2" id="search-resultsitem">
                                                                </div>
                                                                <button class="btn btn-danger" id="DeleteRow"
                                                                    type="button">
                                                                    Remove
                                                                </button>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div id="newinput"></div>

                                                            <div class="col">
                                                                <div id="rowAdder" class="btn btn-primary">
                                                                    Add</div>
                                                            </div>
                                                        </div>

                                                        <!-- Script untuk menambahkan input item baru -->
                                                        <script>
                                                            // Initialize counter for unique IDs
                                                            let counter = 1;

                                                            $("#rowAdder").click(function() {
                                                                newRowAdd =
                                                                    `<div id="row${counter}">
        <div class="card-header">
            <h5 class="card-title mb-0">Item</h5>
        </div>
        <div class="card-body">
            <input type="text" id="searchitem${counter}" placeholder="Item" list="item" name="item[]" class="form-control">
            <datalist id="item">
                @foreach ($item as $data)
                    <option>{{ $data->item }}</option>
                @endforeach
            </datalist>
            <div class="pt-2" id="search-resultsitem${counter}"></div>
            <button class="btn btn-danger" id="DeleteRow${counter}" type="button">Remove</button>
        </div>
    </div>`;

                                                                // Tambahkan elemen baru setelah elemen dengan ID "rowAdder"
                                                                $("#newinput").append(newRowAdd);

                                                                // Mendaftarkan fungsi handleSearchItem untuk elemen baru yang ditambahkan
                                                                $(`#searchitem${counter}`).on('keyup', handleSearchItem);

                                                                counter++;
                                                            });
                                                        </script>

                                                        <!-- Script untuk menangani pencarian item -->
                                                        <script>
                                                            function handleSearchItem() {
                                                                var query = $(this).val();
                                                                if (query !== '') {
                                                                    $.ajax({
                                                                        url: '/searchitemresult',
                                                                        method: 'GET',
                                                                        data: {
                                                                            query: query
                                                                        },
                                                                        success: function(data) {
                                                                            $(this).nextAll(".pt-2").first().html(data);
                                                                        }.bind(
                                                                            this) // Perhatikan bind(this) untuk mempertahankan konteks elemen yang memicu pencarian
                                                                    });
                                                                } else {
                                                                    $(this).nextAll(".pt-2").first().html('');
                                                                }
                                                            }

                                                            // Mendaftarkan fungsi handleSearchItem untuk elemen dengan ID "searchitem"
                                                            $(document).ready(function() {
                                                                $('#searchitem').on('keyup', handleSearchItem);
                                                            });
                                                        </script>






                                                    </div>
                                </main>
                                <div class="container">
                                    <button class="btn btn-dark" type="submit" style="width: 100%">Submit</button>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
    </div>
    </section>
    </div>
    </main>

    </div>
@endsection
