@if (count($resultsitem) > 0)
    <ul>
        @foreach ($resultsitem as $result)
            <div class="row">
                <div class="col">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Size</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control" placeholder="" name="size[]" value="{{ $result->size }}"
                            readonly="readonly">
                    </div>
                </div>
                <div class="col">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Specs</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control" placeholder="" name="specs[]"
                            value="{{ $result->specs }}" readonly="readonly">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Unit</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control" placeholder="" name="unit[]"
                            value="{{ $result->unit }}" readonly="readonly">
                    </div>
                </div>
                <div class="col">
                    <div class="card-header">
                        <h5 class="card-title mb-0">QTY</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control" placeholder="" name="qty[]" required>
                    </div>
                </div>
                <div class="col">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Price</h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control" placeholder="" name="price[]"
                            value="{{ $result->price }}" readonly="">
                    </div>
                </div>
                <div class="row">


                    <div class="col">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Eta User</h5>
                        </div>
                        <div class="card-body">
                            <input type="date" name="etauser[]" class="form-control" required />

                        </div>
                    </div>

                    <div class="col">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Eta Auto</h5>
                        </div>
                        <div class="card-body">
                            <input type="date" name="etaauto[]" class="form-control" required />
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    @else
        <p>No boxes found.</p>
@endif
