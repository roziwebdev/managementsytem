<?php

namespace App\Http\Controllers\Hrd\Kadept;

use App\Http\Controllers\Controller;
use App\Models\Karyawan;
use App\Models\Lembur;
use Illuminate\Http\Request;

class LemburkadeptController extends Controller
{
public function index(Request $request){

    $query = Lembur::query();
    $karyawan = Karyawan::all();
    $applyPagination = true; // Variable untuk menentukan apakah paginasi akan diterapkan

    // Filter berdasarkan pencarian ID atau produk
    if ($request->has('search')) {
        $searchValue = $request->input('search');

        $query->where(function($q) use ($searchValue) {
            $q->where('id', $searchValue)
              ->orWhere('namakaryawan', 'like', '%' . $searchValue . '%');
        });

    }

    // Filter berdasarkan status dan rentang tanggal jika keduanya diisi
    if ($request->has('status') && $request->has('tgl_mulai') && $request->has('tgl_akhir')) {
        $statusFilter = $request->input('status');
        $tglMulai = $request->input('tgl_mulai');
        $tglAkhir = $request->input('tgl_akhir');
        $query->where('status', $statusFilter)
              ->whereBetween('tgllembur', [$tglMulai, $tglAkhir]);

        // Nonaktifkan paginasi jika ada filter
        $applyPagination = false;
    }

    // Filter berdasarkan status jika hanya status yang diisi
    elseif ($request->has('status') && empty($request->input('tgl_mulai')) && empty($request->input('tgl_akhir'))) {
        $statusFilter = $request->input('status');
        $query->where('status', $statusFilter);

        // Nonaktifkan paginasi jika ada filter
        $applyPagination = false;
    }

    // Filter berdasarkan rentang tanggal jika hanya tanggal yang diisi
    elseif ($request->has('tgl_mulai') && $request->has('tgl_akhir')) {
        $tglMulai = $request->input('tgl_mulai');
        $tglAkhir = $request->input('tgl_akhir');

        $query->whereBetween('tgllembur', [$tglMulai, $tglAkhir]);

        // Nonaktifkan paginasi jika ada filter
        $applyPagination = false;
    }

    // Terapkan paginasi jika tidak ada filter
    $lemburs = $applyPagination ? $query->paginate(15) : $query->get();

    return view('role.hrd.lembur.lemburkadept.listlembur', compact('lemburs', 'karyawan', 'applyPagination'));
}
    public function store(Request $request){
        $lembur = new Lembur;
        $lembur->tgllembur = $request->tgllembur;
        $lembur->departement = json_encode($request->departement);
        $lembur->namakaryawan = json_encode($request->namakaryawan);
        $lembur->jabatan = json_encode($request->jabatan);
        $lembur->mulai = json_encode($request->mulai);
        $lembur->istirahat = json_encode($request->istirahat);
        $lembur->berakhir = json_encode($request->berakhir);
        $lembur->keteranganpekerjaan = json_encode($request->keteranganpekerjaan);
        $lembur->hasillembur = json_encode($request->hasillembur);
        $lembur->estimasi = json_encode($request->estimasi);
        $lembur->unit= json_encode($request->unit);
        $lembur->pemberiperintah = $request->pemberiperintah;
        $lembur->status = $request->status;
        $lembur->save();
        return redirect()->route('lemburkadept.index');
    }

    public function edit($id){
        $lembur = Lembur::find($id);
        return view('role.hrd.lembur.lemburkadept.editlembur', compact('lembur'));
    }

    public function update(Request $request, $id){
        $lembur = Lembur::find($id);
        $lembur->tgllembur = $request->tgllembur;
        $lembur->departement = $request->departement;
        $lembur->namakaryawan = $request->namakaryawan;
        $lembur->jabatan = $request->jabatan;
        $lembur->mulai = $request->mulai;
        $lembur->istirahat = $request->istirahat;
        $lembur->berakhir = $request->berakhir;
        $lembur->keteranganpekerjaan = $request->keteranganpekerjaan;
        $lembur->hasillembur = $request->hasillembur;
        $lembur->pemberiperintah = $request->pemberiperintah;
        $lembur->save();
        return redirect()->route('lemburkadept.index');
    }

    public function getdatakaryawan($kodekar)
    {
        $karyawan = Karyawan::where('nama', $kodekar)->first();
        if ($karyawan) {
            return response()->json(['jabatan' => $karyawan->jabatan, 'departement' => $karyawan->departement]);
        } else {
            return response()->json(['error' => 'Data customer tidak ditemukan.'], 404);
        }
    }
     public function updateStatuskadept(Request $request, $id)
    {
        $newStatus = $request->input('newStatus');
        $lembur = Lembur::find($id);
        if (!$lembur) {
            return redirect()->back()->with('error', 'Materialrequest tidak ditemukan.');
        }
        $lembur->status = $newStatus;
        $lembur->save();
        return redirect()->back()->with('success', 'Status berhasil diperbarui.');
    }
}
