@extends('role.purchasing.layoutsvendor.main')
@section('main-container')
    <main class="content">
        <div class="container-fluid p-0">
            <div class="mb-5 text-center">
                <h1 class="h1 d-inline align-middle">Form</h1>
                <a class="badge bg-dark text-white ms-2">
                    Dokumentasi Supplier ARJAYA
                </a>
            </div>
            <form method="POST" action="{{ route('dokumentasisupplier.store') }}" enctype="multipart/form-data">
                @csrf
                <div class="container-xl">
                    <div class="">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Tipe Supplier</h5>
                            </div>
                            <div class="card-body">

                                <select name="type" class="form-select" aria-label="Floating label select example">
                                    <option selected>Open this select menu</option>
                                    <option value="INK">INK (Tinta)</option>
                                    <option value="PP">PP (Kertas)</option>
                                    <option value="CH">CH (Chemical)</option>
                                    <option value="EKP">EKP (Ekspedisi)</option>
                                    <option value="LL">LL (Lain-Lain)</option>
                                </select>
                            </div>
                        </div>
            </form>
        </div>
        <div class="container">
            <button class="btn btn-dark" type="submit" style="width: 100%">Submit</button>
        </div>
    </main>
@endsection
