<?php

namespace App\Http\Controllers\Sales;

use App\Models\Customer;
use App\Models\Plant;
use App\Models\Sales;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class SalesController extends Controller
{

    public function dashboard (){
        return view('role.sales.salesdept.dashboard');
    }

    public function index(Request $request) {
    $query = Sales::query();
    $plants = Plant::all();
    $cust = Customer::all();

    // Pencarian berdasarkan ID atau produk
    if ($request->has('search')) {
        $searchValue = $request->input('search');

        $query->where(function($q) use ($searchValue) {
            $q->where('id', $searchValue)
              ->orWhere('product', 'like', '%' . $searchValue . '%');
        });
    }

    if ($request->has('statusproduct')) {
        $statusFilter = $request->input('statusproduct');
        $query->where('statusproduct', $statusFilter);
    }

    // Filter produk berdasarkan ascending (asc) atau descending (desc)
    $sortBy = $request->input('sort_by', null);

    if (!$sortBy) {
        // Jika tidak ada query pencarian, urutkan berdasarkan updated_at terbaru
        $query->orderByDesc('updated_at');
    } elseif ($sortBy == 'asc') {
        // Jika ada query pencarian dan sort_by = asc, urutkan berdasarkan id secara ascending
        $query->orderBy('id');
    } elseif ($sortBy == 'desc') {
        // Jika ada query pencarian dan sort_by = desc, urutkan berdasarkan id secara descending
        $query->orderByDesc('id');
    } elseif ($sortBy == 'ascproduct') {
        // Jika ada query pencarian dan sort_by = asc, urutkan berdasarkan product secara ascending
        $query->orderBy('product');
    } elseif ($sortBy == 'descproduct') {
        // Jika ada query pencarian dan sort_by = desc, urutkan berdasarkan product secara descending
        $query->orderByDesc('product');
    }

    // Ambil data berdasarkan query yang telah dibuat
    $salescontract = $query->paginate(20);
    return view('role.sales.salesdept.salescontract.listsales', compact('plants','salescontract', 'cust'));
}




        public function show(Sales $sales, $id)
    {
        $details = Sales::find($id);
        return view('role.sales.salesdept.salescontract.show', compact('details'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(Request $request)
    {

        $sales = new Sales;
        $sales->po = $request->po;
        $sales->tanggalpo = $request->tanggalpo;
        $sales->scode = $request->scode;
        $sales->customer = $request->customer;
        $sales->address = $request->address;
        $sales->up = $request->up;
        $sales->plantcode = $request->plantcode;
        $sales->product = json_encode($request->product);
        $sales->sap = json_encode($request->sap);
        $sales->material = json_encode($request->material);
        $sales->specs = json_encode($request->specs);
        $sales->size = json_encode($request->size);
        $sales->finishing = json_encode($request->finishing);
        $sales->qty = json_encode($request->qty);
        $sales->unit = json_encode($request->unit);
        $sales->price = json_encode($request->price);
        $sales->total = json_encode($request->total);
        $sales->etauser = json_encode($request->etauser);
        $sales->toleransi = json_encode($request->toleransi);
        $sales->notesc = json_encode($request->notesc);
        $sales->statusproduct = json_encode($request->statusproduct);
        $sales->job = $request->job;
        $sales->dp = $request->dp;
        $sales->statusjob = $request->statusjob;
        $sales->selisih = $request->selisih;
        $sales->jumlahkirim = $request->jumlahkirim;
        $sales->nosj = $request->nosj;
        $sales->statussc = $request->statussc;
        $sales->persen = $request->persen;
        $sales->save();
        return redirect()->route('salesdept.index');
    }

    public function getdatacust($kodecust)
{
    $customer = Customer::where('customer', $kodecust)->first();

    if ($customer) {
        return response()->json(['up' => $customer->up, 'address' => $customer->address]);
    } else {
        return response()->json(['error' => 'Data customer tidak ditemukan.'], 404);
    }
}
    public function getdataplant($plant)
    {
        $plants = Plant::where('plant', $plant)->first();

        if ($plants) {
            return response()->json(['kodeplant' => $plants->kodeplant, 'address' => $plants->address]);
        } else {
            return response()->json(['error' => 'Data customer tidak ditemukan.'], 404);
        }
    }



    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Sales $sales,$id)
    {
        $plants = Plant::all();
        $cust = Customer::all();
        $salescontract = Sales::find($id);
        return view('role.sales.salesdept.salescontract.edit', compact('plants','cust','salescontract'));
    }

    /**
     * Update the specified resource in storage.
     */
   public function update(Request $request, $id)
{
    $sales = Sales::find($id);
    $sales->po = $request->po;
    $sales->tanggalpo = $request->tanggalpo;
    $sales->scode = $request->scode;
    $sales->customer = $request->customer;
    $sales->address = $request->address;
    $sales->up = $request->up;
    $sales->plantcode = $request->plantcode;
    $sales->product = json_encode($request->product);
    $sales->sap = json_encode($request->sap);
    $sales->material = json_encode($request->material);
    $sales->specs = json_encode($request->specs);
    $sales->size = json_encode($request->size);
    $sales->finishing = json_encode($request->finishing);
    $sales->qty = json_encode($request->qty);
    $sales->unit = json_encode($request->unit);
    $sales->price = json_encode($request->price);
    $sales->total = json_encode($request->total);
    $sales->etauser = json_encode($request->etauser);
    $sales->toleransi = json_encode($request->toleransi);
    $sales->notesc = json_encode($request->notesc);
    $sales->statusproduct = json_encode($request->statusproduct);
    $sales->job = $request->job;
    $sales->dp = $request->dp;
    $sales->statusjob = $request->statusjob;
    $sales->selisih = $request->selisih;
    $sales->jumlahkirim = $request->jumlahkirim;
    $sales->nosj = $request->nosj;
    $sales->statussc = $request->statussc;
    $sales->persen = $request->persen;
    $sales->save();

    return redirect()->route('salesdept.index')->with('success', 'Sales record updated successfully');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Sales $sales)
    {
        //
    }

    public function print($id){
            $sc = Sales::find($id);
            return view('role.sales.salesdept.salescontract.print', compact('sc'));
    }

}
