<?php

namespace App\Http\Controllers\Sales;

use App\Models\Customer;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Customer::query();

           if ($request->has('search')) {
        $searchValue = $request->input('search');

        $query->where(function($q) use ($searchValue) {
            $q->where('id', $searchValue)
              ->orWhere('customer', 'like', '%' . $searchValue . '%');
        });
    }

    // Filter produk berdasarkan ascending (asc) atau descending (desc)
    $sortBy = $request->input('sort_by', null);

    if (!$sortBy) {
        // Jika tidak ada query pencarian, urutkan berdasarkan updated_at terbaru
        $query->orderByDesc('id');
    } elseif ($sortBy == 'asc') {
        // Jika ada query pencarian dan sort_by = asc, urutkan berdasarkan id secara ascending
        $query->orderBy('id');
    } elseif ($sortBy == 'desc') {
        // Jika ada query pencarian dan sort_by = desc, urutkan berdasarkan id secara descending
        $query->orderByDesc('id');
    } elseif ($sortBy == 'ascccustomer') {
        // Jika ada query pencarian dan sort_by = asc, urutkan berdasarkan product secara ascending
        $query->orderBy('customer');
    } elseif ($sortBy == 'desccustomer') {
        // Jika ada query pencarian dan sort_by = desc, urutkan berdasarkan product secara descending
        $query->orderByDesc('customer');
    }

    // Ambil data berdasarkan query yang telah dibuat
        $cust = $query->paginate(15);
        return view('role.sales.salesdept.customer.listcustomer', compact('cust'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $cust = new Customer;
        $cust->customer = $request->customer;
        $cust->npwp = $request->npwp;
        $cust->email = $request->email;
        $cust->phone = $request->phone;
        $cust->up = $request->up;
        $cust->kodecust = $request->kodecust;
        $cust->address = $request->address;
        $cust->save();
        return redirect()->route('customer.index');

    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Customer $customer, $id)
    {
        $cust = Customer::find($id);
        $cust->customer = $request->customer;
        $cust->npwp = $request->npwp;
        $cust->email = $request->email;
        $cust->phone = $request->phone;
        $cust->up = $request->up;
        $cust->kodecust = $request->kodecust;
        $cust->save();
        return redirect()->route('customer.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        //
    }
}
