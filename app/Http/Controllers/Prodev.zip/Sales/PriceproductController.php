<?php

namespace App\Http\Controllers\Sales;

use App\Models\Priceproduct;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class PriceproductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $priceproduct = Priceproduct::all();
        return view('role.sales.salesdept.priceproduct.listpriceproduct', compact('priceproduct'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Priceproduct $priceproduct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Priceproduct $priceproduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Priceproduct $priceproduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Priceproduct $priceproduct)
    {
        //
    }
}
